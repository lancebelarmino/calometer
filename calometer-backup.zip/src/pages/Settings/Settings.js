import useStyles from './Settings.styles';

export const Settings = () => {
  const { classes } = useStyles();
  return <div>Settings</div>;
};
