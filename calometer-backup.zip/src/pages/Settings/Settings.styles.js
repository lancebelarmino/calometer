import { createStyles } from '@mantine/core';

const useStyles = createStyles((theme) => ({}));

export default useStyles;
