export { Reset as default } from '../pages/Reset/Reset.js';
