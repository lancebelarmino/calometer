export { Register as default } from '../pages/Register/Register.js';
