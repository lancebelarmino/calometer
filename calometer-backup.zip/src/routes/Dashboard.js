export { Dashboard as default } from '../pages/Dashboard/Dashboard.js';
