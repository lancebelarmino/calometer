export { Tracker as default } from '../pages/Tracker/Tracker.js';
