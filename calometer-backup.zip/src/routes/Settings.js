export { Settings as default } from '../pages/Settings/Settings.js';
