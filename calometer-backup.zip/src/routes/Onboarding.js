export { Onboarding as default } from '../pages/Onboarding/Onboarding.js';
