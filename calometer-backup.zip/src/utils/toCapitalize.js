const toCapitalize = (string) => string.charAt(0).toUpperCase() + string.slice(1);

export default toCapitalize;
