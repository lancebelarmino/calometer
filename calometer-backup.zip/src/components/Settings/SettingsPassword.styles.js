import { createStyles } from '@mantine/core';

const useStyles = createStyles((theme) => ({
  header: {
    marginBottom: 40,
  },

  headerTitle: {
    marginBottom: 8,
  },

  divider: {
    marginBottom: 40,
    color: theme.colors.gray[0],
  },

  formRow: {
    position: 'relative',

    '&:not(:last-of-type)': {
      marginBottom: 40,
    },
  },

  successPopup: {
    left: '50%',
    transform: 'translateX(-50%)',
  },
}));

export default useStyles;
